/*
 * ****************************************************************************
  * Copyright 2016, Govardhan. All rights reserved. An
 * unpublished work of Govardhan may only be used in accordance
 * with a license agreement with Govardhan. Any unauthorized
 * use, duplication or disclosure is prohibited.
 * ****************************************************************************
 * */
angular.module('sortingApp',
		['restangular','ngRoute','ngMessages']);
angular.module('sortingApp').run(function() {
	
});

